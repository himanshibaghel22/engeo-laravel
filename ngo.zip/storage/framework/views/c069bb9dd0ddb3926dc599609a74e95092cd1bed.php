
<?php $__env->startSection('contant'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\engeo-laravel\resources\views/admin/manage_notification.blade.php ENDPATH**/ ?>